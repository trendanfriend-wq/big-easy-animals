# Baryonyx coloring-book video — credits

## Narration
- Voice: Microsoft Edge TTS `en-US-EmmaNeural` (rate −8%, pitch −2Hz) via edge-tts
- Script (kid-facing; extinct + movie-style sound):
  "This is a Baryonyx — a fish-eating dinosaur with a long crocodile snout and a giant thumb claw! Baryonyx lived long ago in what is now England. Baryonyx is extinct now, so we study fossils and museum models. Any sound you hear is a fun movie-style sound, not a real recording. Now listen... this is what a Baryonyx sounds like!"

## Creature sound (honest label)
- Note: **Baryonyx is extinct** — there is **no real wildlife recording**. The sound used here is a **movie-style / Foley** call, clearly labeled in narration and credits.
- File: `baryonyx_sound.mp3` (processed mono 44.1 kHz; ≈ 5.28 s — gated standalone call after narration)
- Primary: “dinosaur roar 1” by Logicogonist
  - License: Creative Commons 0 (CC0 1.0) — https://creativecommons.org/publicdomain/zero/1.0/
  - URL: https://freesound.org/people/Logicogonist/sounds/810951/
  - Note: Designed / Foley movie-style dinosaur roar (not a biological Baryonyx recording). Chosen as a **deep dry roar** (high-frequency energy ratio ≈ 0.01–0.02 vs the low band; not a wet mouth / finger-in-mouth texture). Unique vs Vol1 T.rex (643747) / Allosaurus (578601) / Velociraptor (639448) and Vol2 Spinosaurus alligator (675512) / Dilophosaurus (479380) / Giganotosaurus (529462). Preview used from Freesound CDN, offset ≈ 0.35 s, trimmed ≈ 5.28 s.
- Processing: high-pass/low-pass + FFT denoise + dynaudnorm + loudnorm + peak limit. Mono 44.1 kHz.

## Video clips (free / commercial-ok only)

### Bone sculpture / fossil mount (museum-style) — wide first
#### bone_1_wide.mp4
- Still photo Ken Burns: Wikimedia Commons — File:Baryonyx walkeri mount NMNS.jpg
- URL: https://commons.wikimedia.org/wiki/File:Baryonyx_walkeri_mount_NMNS.jpg
- Author: ★Kumiko★ (Flickr)
- License: CC BY-SA 2.0 — https://creativecommons.org/licenses/by-sa/2.0
- Content: National Museum of Nature and Science, Tokyo (Giga Dinosaur Exhibition) — standing Baryonyx walkeri skeletal mount. Cropped to drop the floor plaque and the neighboring skeleton sliver. Wide Ken Burns on dark slate bars (source is wider than 16:9).

#### bone_2_wide.mp4
- Still photo Ken Burns: Wikimedia Commons — File:Baryonyx skeleton 1 NHM.JPG
- URL: https://commons.wikimedia.org/wiki/File:Baryonyx_skeleton_1_NHM.JPG
- Author: Ballista
- License: CC BY-SA 3.0 — https://creativecommons.org/licenses/by-sa/3.0
- Content: Natural History Museum, London — holotype-style Baryonyx wall mount (snout, claw, and hind limb). Museum hall lighting retained.

### ONE alive format (solid dark slate only; NO human silhouette)
#### alive_full_a_scale.mp4 / alive_full_b_scale.mp4 / alive_full_c_scale.mp4
- Source: Wikimedia Commons — File:Baryonyx Animatronics model 1 NHM white background.JPG
- URL: https://commons.wikimedia.org/wiki/File:Baryonyx_Animatronics_model_1_NHM_white_background.JPG
- Author: Ballista (2006 photograph of the NHM display)
- License: CC BY-SA 3.0 — https://creativecommons.org/licenses/by-sa/3.0 — also GFDL 1.2
- Content: **Natural History Museum, London animatronic life model** of Baryonyx (fish-hunting pose). White studio background flood-filled from the borders onto solid dark slate RGB(26,29,44) so teeth stay white. Ken Burns three segments. **No human silhouette. No jungle plate. No foliage.**
- Why this meets the source bar: named natural-history-museum physical life model (same bar as Spinosaurus Museu Blau and Dilophosaurus Münchehagen). **Not** the material-sheet PaleoGeekSquared painting (File:Baryonyx walkeri by PaleoGeek v2.png), which is lone Commons paleoart. Igea / La Era del Peladillo park statue was reviewed but rails cross the legs. The lying-down NHM carcass model sits in a dirt diorama.
- Commons flags this 2006 animatronic as an obsolete restoration (too bulky, deep skull). Still preferred over solo paleoart, same call as the Museu Blau Spinosaurus model.
- Small metal exhibit clips remain on the standing toes. Inpainting them smeared the claws, so the clips were kept rather than inventing toes. They are not a scaffold lattice or a dirty ground line.
- `*_scale.mp4` filenames retained for build.py compatibility but contain **no** human overlay.

## Build
- Assembled with shared `/workspace/doomsday/coloring-book/videos/build.py` (crop-to-fill 854×480 @ 30 fps).
- End card (~3.8 s): “Well done! Color your Baryonyx! Any colors you like!”
- Pre-ending: `baryonyx_mix_pre_ending.mp4`.
- Narration ≈ 23.23 s. Foley ≈ 5.28 s. Final `baryonyx_mix.mp4` ≈ 32.27 s.
- Built on shared box 2026-10-03 (SAST / Africa/Johannesburg).

## Flow
1. Wide bone/skeleton / fossil shots first
2. ONE alive format on solid dark slate — no jungle plate; no Quaternius/toy/low-poly
3. **No human silhouette**
4. EmmaNeural narration → creature sound → Well done end card
5. Honest extinct + movie-style Foley disclosure; claw + long snout (not a Spinosaurus sail)

## Stock gaps / notes
- Alive is a **named museum animatronic** (NHM London), not a paper figure and not solo paleoart.
- NMNS standing mount + NHM London holotype wall mount are the two bone shots.
- PaleoGeek life art was not used.
